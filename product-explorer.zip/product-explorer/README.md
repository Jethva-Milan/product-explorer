# Product Explorer

React + TypeScript + CSS (Vite).

## Run in VS Code
1. Unzip, then in VS Code: File > Open Folder > select `product-explorer`
2. Open the terminal (Ctrl + `) and run:

       npm install
       npm run dev

3. Open the URL shown (usually http://localhost:5173)

Requires Node.js 18+.
