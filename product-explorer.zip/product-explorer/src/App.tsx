import { useState } from 'react';
import { PRODUCTS } from './data/products';
import { useProductFilters } from './hooks/useProductFilters';
import { SearchBar } from './components/SearchBar';
import { CategoryFilter } from './components/CategoryFilter';
import { SortSelect } from './components/SortSelect';
import { ProductGrid } from './components/ProductGrid';
import { EmptyState } from './components/EmptyState';
import './App.css';

export default function App() {
  const {
    query, setQuery,
    category, setCategory,
    sort, setSort,
    visibleProducts,
    hasActiveFilters,
    reset,
  } = useProductFilters(PRODUCTS);

  const [cartCount, setCartCount] = useState(0);

  return (
    <>
      <header className="topbar">
        <div className="topbar__inner">
          <h1 className="logo">Product Explorer</h1>
          <SearchBar value={query} onChange={setQuery} />
          <div className="cart" aria-live="polite">
            Cart <span className="cart__count">{cartCount}</span>
          </div>
        </div>
      </header>

      <div className="page">
        <section className="toolbar" aria-label="Filters">
          <CategoryFilter selected={category} onChange={setCategory} />
          <SortSelect value={sort} onChange={setSort} />
        </section>

        <p className="count" aria-live="polite">
          {visibleProducts.length} {visibleProducts.length === 1 ? 'product' : 'products'}
          {hasActiveFilters && (
            <button type="button" className="link" onClick={reset}>Clear filters</button>
          )}
        </p>

        <main>
          {visibleProducts.length > 0 ? (
            <ProductGrid
              products={visibleProducts}
              onAddToCart={() => setCartCount((c) => c + 1)}
            />
          ) : (
            <EmptyState onReset={reset} />
          )}
        </main>
      </div>
    </>
  );
}
