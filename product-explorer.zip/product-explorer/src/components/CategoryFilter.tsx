import { CATEGORIES } from '../types';
import type { CategoryFilterValue } from '../types';

interface CategoryFilterProps {
  selected: CategoryFilterValue;
  onChange: (category: CategoryFilterValue) => void;
}

const OPTIONS: CategoryFilterValue[] = ['All', ...CATEGORIES];

export function CategoryFilter({ selected, onChange }: CategoryFilterProps) {
  return (
    <div className="chips" role="group" aria-label="Filter by category">
      {OPTIONS.map((option) => (
        <button
          key={option}
          type="button"
          className={`chip${selected === option ? ' chip--active' : ''}`}
          aria-pressed={selected === option}
          onClick={() => onChange(option)}
        >
          {option}
        </button>
      ))}
    </div>
  );
}
