import type { Product } from '../types';
import { StarRating } from './StarRating';
import { ProductImage } from './ProductImage';

const formatPrice = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
});

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const discount = product.originalPrice
    ? Math.round((1 - product.price / product.originalPrice) * 100)
    : 0;

  return (
    <article className="card">
      <div className="card__media">
        <ProductImage src={product.image} alt={product.name} category={product.category} />
        {discount > 0 && <span className="card__badge">-{discount}%</span>}
      </div>

      <div className="card__body">
        <p className="card__meta">
          <span className="card__brand">{product.brand}</span>
          <span className="card__category">{product.category}</span>
        </p>
        <h3 className="card__name">{product.name}</h3>
        <StarRating rating={product.rating} reviews={product.reviews} />

        <div className="card__footer">
          <p className="card__price">
            <span className="card__price-now">{formatPrice.format(product.price)}</span>
            {product.originalPrice && (
              <s className="card__price-was">{formatPrice.format(product.originalPrice)}</s>
            )}
          </p>
          <button
            type="button"
            className="btn btn--small"
            onClick={() => onAddToCart(product)}
            aria-label={`Add ${product.name} to cart`}
          >
            Add
          </button>
        </div>
      </div>
    </article>
  );
}
