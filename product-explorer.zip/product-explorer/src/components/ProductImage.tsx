import { useState } from 'react';
import type { Category } from '../types';

const ICONS: Record<Category, string> = {
  Electronics: '🎧',
  Fashion: '👕',
  Home: '🛋️',
  Sports: '🏃',
  Books: '📚',
};

const TINTS: Record<Category, string> = {
  Electronics: 'linear-gradient(135deg, #dbe7ff, #b9cdf5)',
  Fashion: 'linear-gradient(135deg, #ffe3ea, #f5bccb)',
  Home: 'linear-gradient(135deg, #fff0d1, #f5d79b)',
  Sports: 'linear-gradient(135deg, #d9f5e3, #a9e0bd)',
  Books: 'linear-gradient(135deg, #ece0ff, #cdb7f2)',
};

interface ProductImageProps {
  src: string;
  alt: string;
  category: Category;
}

export function ProductImage({ src, alt, category }: ProductImageProps) {
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div className="card__fallback" style={{ background: TINTS[category] }} role="img" aria-label={alt}>
        <span className="card__fallback-icon" aria-hidden="true">{ICONS[category]}</span>
      </div>
    );
  }

  return (
    <div className={`card__photo${loaded ? '' : ' card__photo--loading'}`}>
      <img
        src={src}
        alt={alt}
        loading="lazy"
        referrerPolicy="no-referrer"
        onLoad={() => setLoaded(true)}
        onError={() => setFailed(true)}
      />
    </div>
  );
}
