import type { ChangeEvent } from 'react';
import type { SortOrder } from '../types';

interface SortSelectProps {
  value: SortOrder;
  onChange: (value: SortOrder) => void;
}

export function SortSelect({ value, onChange }: SortSelectProps) {
  const handleChange = (e: ChangeEvent<HTMLSelectElement>) =>
    onChange(e.target.value as SortOrder);

  return (
    <div className="sort">
      <label htmlFor="sort">Sort by</label>
      <select id="sort" value={value} onChange={handleChange}>
        <option value="default">Featured</option>
        <option value="price-asc">Price: low to high</option>
        <option value="price-desc">Price: high to low</option>
      </select>
    </div>
  );
}
