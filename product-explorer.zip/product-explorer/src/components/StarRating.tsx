interface StarRatingProps {
  rating: number;
  reviews: number;
}

export function StarRating({ rating, reviews }: StarRatingProps) {
  const fill = `${(rating / 5) * 100}%`;
  return (
    <div className="rating" aria-label={`Rated ${rating} out of 5 from ${reviews} reviews`}>
      <span className="rating__stars" aria-hidden="true">
        <span className="rating__base">★★★★★</span>
        <span className="rating__fill" style={{ width: fill }}>★★★★★</span>
      </span>
      <span className="rating__count">
        {rating.toFixed(1)} ({reviews.toLocaleString('en-US')})
      </span>
    </div>
  );
}
