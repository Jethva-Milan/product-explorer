import type { Product } from '../types';

// Placeholder photos from picsum.photos. Replace with your own image URLs if you prefer.
// If an image fails to load, the card shows a category illustration instead.
const img = (_keywords: string, id: number) =>
  `https://picsum.photos/seed/product-${id}/640/480`;

export const PRODUCTS: Product[] = [
  { id: 1, name: 'Noise Cancelling Headphones', brand: 'Sonora', price: 129.99, originalPrice: 169.99, rating: 4.6, reviews: 2184, category: 'Electronics', image: img('headphones', 1) },
  { id: 2, name: 'Mechanical Keyboard', brand: 'Keystone', price: 89.5, rating: 4.4, reviews: 913, category: 'Electronics', image: img('keyboard', 2) },
  { id: 3, name: 'Fitness Smart Watch', brand: 'Pulse', price: 199, originalPrice: 249, rating: 4.3, reviews: 1507, category: 'Electronics', image: img('smartwatch', 3) },
  { id: 4, name: 'Classic Denim Jacket', brand: 'Harbor & Co', price: 74.99, rating: 4.5, reviews: 642, category: 'Fashion', image: img('denim,jacket', 4) },
  { id: 5, name: 'Everyday Canvas Sneakers', brand: 'Stride', price: 49.9, originalPrice: 64.9, rating: 4.2, reviews: 3320, category: 'Fashion', image: img('sneakers', 5) },
  { id: 6, name: 'Leather Commuter Backpack', brand: 'Harbor & Co', price: 119, rating: 4.7, reviews: 478, category: 'Fashion', image: img('backpack', 6) },
  { id: 7, name: 'Ceramic Table Lamp', brand: 'Lumen Home', price: 38.25, rating: 4.1, reviews: 256, category: 'Home', image: img('table,lamp', 7) },
  { id: 8, name: 'Linen Throw Blanket', brand: 'Hearth', price: 54, originalPrice: 68, rating: 4.8, reviews: 1189, category: 'Home', image: img('blanket,sofa', 8) },
  { id: 9, name: 'Cast Iron Skillet 12"', brand: 'Forge', price: 42.75, rating: 4.9, reviews: 5402, category: 'Home', image: img('skillet,cooking', 9) },
  { id: 10, name: 'Non-Slip Yoga Mat', brand: 'Flexa', price: 29.99, rating: 4.4, reviews: 2071, category: 'Sports', image: img('yoga,mat', 10) },
  { id: 11, name: 'Trail Running Shoes', brand: 'Summit', price: 109.95, originalPrice: 139.95, rating: 4.5, reviews: 836, category: 'Sports', image: img('running,shoes', 11) },
  { id: 12, name: 'Adjustable Dumbbell Set', brand: 'IronWorks', price: 149, rating: 4.6, reviews: 694, category: 'Sports', image: img('dumbbell', 12) },
  { id: 13, name: 'Clean Code Handbook', brand: 'Page & Pixel', price: 34.99, rating: 4.7, reviews: 3015, category: 'Books', image: img('book,programming', 13) },
  { id: 14, name: 'The Pragmatic Programmer', brand: 'Page & Pixel', price: 27.5, originalPrice: 39.99, rating: 4.8, reviews: 4120, category: 'Books', image: img('books,desk', 14) },
  { id: 15, name: 'Atlas of the Night Sky', brand: 'Orbit Press', price: 22, rating: 4.5, reviews: 318, category: 'Books', image: img('night,sky,stars', 15) },
];
