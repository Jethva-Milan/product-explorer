import { useCallback, useMemo, useState } from 'react';
import type { CategoryFilterValue, Product, SortOrder } from '../types';
import { useDebouncedValue } from './useDebouncedValue';

export function useProductFilters(products: Product[]) {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<CategoryFilterValue>('All');
  const [sort, setSort] = useState<SortOrder>('default');

  const debouncedQuery = useDebouncedValue(query);

  const visibleProducts = useMemo(() => {
    const term = debouncedQuery.trim().toLowerCase();

    const filtered = products.filter(
      (p) =>
        (category === 'All' || p.category === category) &&
        p.name.toLowerCase().includes(term),
    );

    if (sort === 'default') return filtered;
    // copy before sorting so we never mutate the source array
    return [...filtered].sort((a, b) =>
      sort === 'price-asc' ? a.price - b.price : b.price - a.price,
    );
  }, [products, debouncedQuery, category, sort]);

  const hasActiveFilters = query !== '' || category !== 'All' || sort !== 'default';

  const reset = useCallback(() => {
    setQuery('');
    setCategory('All');
    setSort('default');
  }, []);

  return {
    query, setQuery,
    category, setCategory,
    sort, setSort,
    visibleProducts,
    hasActiveFilters,
    reset,
  };
}
