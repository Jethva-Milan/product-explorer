export const CATEGORIES = ['Electronics', 'Fashion', 'Home', 'Sports', 'Books'] as const;

export type Category = (typeof CATEGORIES)[number];
export type CategoryFilterValue = Category | 'All';
export type SortOrder = 'default' | 'price-asc' | 'price-desc';

export interface Product {
  id: number;
  name: string;
  brand: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  category: Category;
  image: string;
}
